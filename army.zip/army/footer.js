const domContainer = document.
import react from 'react';
const footer = () =>
return (
	<div class="nosotros">
		<h2>Sobre nosotros</h2>
		<p> nkfurter tenderloin jowl turducken. Pork chop pork loin brisket chuck capicola, tenderloin ribeye spare ribs sirloin kielbasa andouille. Cupim short loin meatloaf doner fatback kielbasa, frankfurter bresaola capicola buffalo landjaeger porchetta beef ribs. 
		</p>
	</div> 
	<p class="copyright">
		Todos los derechos reservados &copy;. Army of Makers 2018
	</p>

)

export default footer;